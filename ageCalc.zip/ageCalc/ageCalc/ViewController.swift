//
//  ViewController.swift
//  ageCalc
//
//  Created by Jack Younger on 9/23/19.
//  Copyright © 2019 Jack Younger. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var age: UITextField!
    @IBOutlet weak var hadBirthd: UISwitch!
    @IBOutlet weak var submit: UIButton!
    @IBOutlet weak var answer: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func calcAge(_ sender: UIButton) {
        var ageVal = String(age.text)
        ageVal = Int(ageVal)
        if ageVal != nil {
            let final = (2019 - ageVal)
            if hadBirthd.isOn == false{
                ageVal -= 1
            }
             "You are " + ageVal + " years old!"
        } else {
            answer.text = "Hey, that doesn't work!"
        }
        
        
    }



}

